package com.zybooks.project3;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {User.class, WeightEntry.class, GoalWeight.class}, version = 2)
@TypeConverters({Converters.class}) // Add TypeConverters if needed for Date
public abstract class AppDatabase extends RoomDatabase {
    public abstract UserDao userDao();
    public abstract WeightEntryDao weightEntryDao();
    public abstract GoalWeightDao goalWeightDao();

    private static AppDatabase INSTANCE;
    static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            // Create the new tables for WeightEntry and GoalWeight
            database.execSQL("CREATE TABLE IF NOT EXISTS `WeightEntry` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `user_id` INTEGER NOT NULL, `weight` REAL NOT NULL, `date` INTEGER NOT NULL)");
            database.execSQL("CREATE TABLE IF NOT EXISTS `GoalWeight` (`userId` INTEGER NOT NULL, `goal_weight` REAL NOT NULL, PRIMARY KEY(`userId`))");
        }
    };

    public static AppDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, "user-database")
                            .addMigrations(MIGRATION_1_2) // Use manual migration
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}

