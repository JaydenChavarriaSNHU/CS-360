package com.zybooks.project3;

import androidx.room.Database;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

@Database(entities = {User.class, WeightEntry.class, GoalWeight.class}, version = 2)
@TypeConverters({Converters.class}) // Add TypeConverters needed for Date
public abstract class WeightDatabase extends RoomDatabase {
    public abstract UserDao userDao();
    public abstract WeightEntryDao weightEntryDao();
    public abstract GoalWeightDao goalWeightDao();
}

