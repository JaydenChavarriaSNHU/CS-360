// WeightEntry.java
package com.zybooks.project3;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import java.util.Date;

@Entity
public class WeightEntry {
    @PrimaryKey(autoGenerate = true)
    public int id;

    @ColumnInfo(name = "user_id") // Assuming you have a user ID to associate weights
    public int userId;

    @ColumnInfo(name = "weight")
    public double weight;

    @ColumnInfo(name= "date")
    public Date date;
}

