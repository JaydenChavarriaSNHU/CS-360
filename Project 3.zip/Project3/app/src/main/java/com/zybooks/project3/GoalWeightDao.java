package com.zybooks.project3;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

@Dao
public interface GoalWeightDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) // Replace existing goal for the same user
    void insert(GoalWeight goalWeight);

    @Query("SELECT * FROM GoalWeight WHERE userId = :userId")
    GoalWeight getGoalWeightForUser(int userId);
}
