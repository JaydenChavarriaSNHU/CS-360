package com.zybooks.project3;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class WeightHistoryActivity extends AppCompatActivity {

    private GridView weightGrid;
    private AppDatabase database;
    private int userId; // Get the logged-in user's ID
    private List<WeightEntry> weightEntries;
    private Button deleteEntryButton;
    private Button addEntryButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weight_history);

        weightGrid = findViewById(R.id.weight_grid);
        database = ((MyApplication) getApplication()).getDatabase();// Fetch weight entries for the user
        userId = getIntent().getIntExtra("userId", -1);
        deleteEntryButton = findViewById(R.id.delete_entry);
        addEntryButton = findViewById(R.id.add_entry);

        addEntryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent to navigate to WeightLoggingActivity
                Intent intent = new Intent(WeightHistoryActivity.this, WeightLoggingActivity.class);
                intent.putExtra("userId", userId); // Pass the userId if needed
                startActivity(intent);
            }
        });

        new Thread(new Runnable() {
            @Override
            public void run() {
                GoalWeight GoalWeight = database.goalWeightDao().getGoalWeightForUser(userId);
                weightEntries = database.weightEntryDao().getWeightEntriesForUser(userId);
                // Prepare data for the GridView
                List<String> gridData = new ArrayList<>();
                // Format the date as needed (e.g., "dd/MM/yyyy")
                SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
                for (WeightEntry entry : weightEntries) {
                    String formattedDate = dateFormat.format(entry.date);;
                    String weight = String.valueOf(entry.weight);

                    // Calculate weight difference from goal
                    String weightDifference = "N/A";
                    if (GoalWeight != null) {
                        double difference = entry.weight - GoalWeight.goalWeight;
                        weightDifference = String.format(Locale.getDefault(), "%+.0f", difference); // Format with + or - sign
                    }
                    gridData.add(formattedDate);
                    gridData.add(weight);
                    gridData.add(weightDifference);
                }
            // Set up the adapter for the GridView
            // Update the GridView on the main thread
                List<WeightEntry> finalWeightEntries = weightEntries;
                runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(WeightHistoryActivity.this, android.R.layout.simple_list_item_1, gridData);
                    weightGrid.setAdapter(adapter);

                    // Set item click listener after setting the adapter
                    deleteEntryButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            // Create a dialog to display the list of weight entries
                            AlertDialog.Builder builder = new AlertDialog.Builder(WeightHistoryActivity.this);
                            builder.setTitle("Select Entry to Delete");

                            // Create an array of strings to display in the dialog
                            String[] entries = new String[weightEntries.size()];
                            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
                            for (int i = 0; i < weightEntries.size(); i++) {
                                entries[i] = dateFormat.format(weightEntries.get(i).date) + " - " + weightEntries.get(i).weight + " Lbs";
                            }

                            builder.setItems(entries, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    // 'which' is the index of the selected entry
                                    final WeightEntry entryToDelete = weightEntries.get(which);

                                    // Delete the entry in a background thread
                                    new Thread(new Runnable() {
                                        @Override
                                        public void run() {
                                            database.weightEntryDao().delete(entryToDelete);

                                            // Refresh the GridView on the main thread
                                            runOnUiThread(new Runnable() {
                                                @Override
                                                public void run() {
                                                    refreshWeightEntries();
                                                }
                                            });
                                        }
                                    }).start();
                                }
                            });
                            builder.show(); // Show the dialog
                        }
                    });
                }
            });
            }
        }).start();
    }

    // Helper method to refresh the weight entries in the GridView
    private void refreshWeightEntries() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                weightEntries = database.weightEntryDao().getWeightEntriesForUser(userId);
                GoalWeight goalWeight = database.goalWeightDao().getGoalWeightForUser(userId); // Fetch goal weight
                List<String> gridData = new ArrayList<>(); // Initialize gridData

                // Prepare data for the GridView
                SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
                for (WeightEntry entry : weightEntries) {
                    String formattedDate = dateFormat.format(entry.date);
                    String weight = String.valueOf(entry.weight);

                    //Calculate weight difference from goal
                    String weightDifference = "N/A";
                    if (goalWeight != null) {
                        double difference = entry.weight - goalWeight.goalWeight;
                        weightDifference = String.format(Locale.getDefault(), "%+.0f", difference);
                    }

                    gridData.add(formattedDate);
                    gridData.add(weight);
                    gridData.add(weightDifference);
                }


                runOnUiThread(new Runnable() {@Override
                public void run() {
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(WeightHistoryActivity.this, android.R.layout.simple_list_item_1, gridData);
                    weightGrid.setAdapter(adapter);
                }
                });
            }
        }).start();
    }
}