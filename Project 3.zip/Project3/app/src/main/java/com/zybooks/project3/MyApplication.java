package com.zybooks.project3;

import android.app.Application;
import androidx.room.Room;

public class MyApplication extends Application {
    private AppDatabase database;

    @Override
    public void onCreate() {
        super.onCreate();
        database = Room.databaseBuilder(this, AppDatabase.class, "user-database").build();
    }

    public AppDatabase getDatabase() {
        return database;
    }
}