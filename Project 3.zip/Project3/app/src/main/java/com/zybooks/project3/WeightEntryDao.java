package com.zybooks.project3;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import java.util.Date;
import java.util.List;

@Dao
public interface WeightEntryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) // Replace existing entry for the same date
    void insert(WeightEntry weightEntry);

    @Query("SELECT * FROM WeightEntry WHERE user_id = :userId ORDER BY date DESC")List<WeightEntry> getWeightEntriesForUser(int userId);

    @Query("SELECT * FROM WeightEntry WHERE user_id = :userId AND date = :date")
    WeightEntry getWeightEntryForDate(int userId, Date date);

    @Delete
        // Add this line to define the delete method
    void delete(WeightEntry weightEntry);
}
