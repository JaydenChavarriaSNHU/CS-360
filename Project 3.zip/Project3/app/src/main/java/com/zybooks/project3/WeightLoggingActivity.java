package com.zybooks.project3;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.view.inputmethod.InputMethodManager;

import com.google.android.material.snackbar.Snackbar;

import java.util.Calendar;
import java.util.Locale;

public class WeightLoggingActivity extends AppCompatActivity{
    private EditText weightEntry;
    private EditText goalEntry;
    private Button submitButton;
    private Button dontSubmitButton;
    private AppDatabase database;
    private int userId;
    private boolean isSmsPermissionGranted = false;
    private static final String PREFS_NAME = "MyPrefs";
    private static final String KEY_SMS_PERMISSION = "isSmsPermissionGranted";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weight_logging_screen);
        userId = getIntent().getIntExtra("userId", -1);

        database = ((MyApplication) getApplication()).getDatabase();
        weightEntry = findViewById(R.id.weightEntry);
        goalEntry = findViewById(R.id.goalEntry);
        submitButton = findViewById(R.id.submitButton);
        dontSubmitButton = findViewById(R.id.dontSubmitButton);
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        isSmsPermissionGranted = prefs.getBoolean(KEY_SMS_PERMISSION, false);
        Log.d("WeightLoggingActivity", "SMS Permission Granted: " + isSmsPermissionGranted);

        // Fetch existing goal weight if available
        new Thread(new Runnable() {
            @Override
            public void run() {
                GoalWeight existingGoal = database.goalWeightDao().getGoalWeightForUser(userId);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (existingGoal != null) {
                            goalEntry.setText(String.valueOf(existingGoal.goalWeight));
                        }
                    }
                });
            }
        }).start();

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weightText = weightEntry.getText().toString();
                String goalText = goalEntry.getText().toString();

                // Check for empty input
                if (weightText.isEmpty() || goalText.isEmpty()) {
                    Toast.makeText(WeightLoggingActivity.this, "Please enter both weight and goal weight.", Toast.LENGTH_SHORT).show();
                    return; // Stop further execution
                }

                new Thread(new Runnable() {
                @Override
                public void run() {
                    double weight = Double.parseDouble(weightText);
                    double goal = Double.parseDouble(goalText);

                    WeightEntry newWeightEntry = new WeightEntry();
                    newWeightEntry.userId = userId;
                    newWeightEntry.weight = weight;
                    newWeightEntry.date = Calendar.getInstance().getTime(); // Current date and time
                    database.weightEntryDao().insert(newWeightEntry);

                    // Update goal weight
                    GoalWeight newGoalWeight = new GoalWeight();
                    newGoalWeight.userId = userId;
                    newGoalWeight.goalWeight = goal;
                    database.goalWeightDao().insert(newGoalWeight);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isSmsPermissionGranted) {
                                double difference = goal - weight;
                                String message = String.format(Locale.getDefault(), "You are currently %+.0f lbs away from your goal weight.", difference);

                                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                                View currentFocus = getCurrentFocus();
                                if (currentFocus != null) {
                                    imm.hideSoftInputFromWindow(currentFocus.getWindowToken(), 0);
                                }

                                // Show Snackbar
                                Log.d("WeightLoggingActivity", "Showing Snackbar");
                                Snackbar.make(findViewById(R.id.weight_logging_screen),
                                        message, Snackbar.LENGTH_LONG).show();

                                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                                    startActivity(new Intent(WeightLoggingActivity.this, WeightHistoryActivity.class));
                                }, 3000);
                            }else {
                                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                                View currentFocus = getCurrentFocus();
                                if (currentFocus != null) {
                                    imm.hideSoftInputFromWindow(currentFocus.getWindowToken(), 0);
                                }
                                startActivity(new Intent(WeightLoggingActivity.this, WeightHistoryActivity.class));
                            }
                        }
                    });
                }
            }).start();
        }
    });

        dontSubmitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(WeightLoggingActivity.this, "Nothing submitted", Toast.LENGTH_SHORT).show();

                // Transition to weight history screen
                startActivity(new Intent(WeightLoggingActivity.this, WeightHistoryActivity.class));

            }
        });
    }
}
