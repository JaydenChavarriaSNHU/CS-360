package com.zybooks.project3;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import at.favre.lib.crypto.bcrypt.BCrypt;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
    private AppDatabase database;
    private static final int SMS_PERMISSION_REQUEST_CODE = 123;
    private static final String PREFS_NAME = "MyPrefs";
    private static final String KEY_SMS_PERMISSION = "isSmsPermissionGranted";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        new Thread(new Runnable() {
            @Override
            public void run() {
                database = ((MyApplication) getApplication()).getDatabase();
            }
        }).start();

        // Initialize views
        Button signupButton = findViewById(R.id.buttonSignup);
        EditText username = findViewById(R.id.editTextTextUsername);
        EditText password = findViewById(R.id.editTextTextPassword);
        Button loginButton = findViewById(R.id.buttonLogin);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        User user = database.userDao().getUserByUsername(username.getText().toString());
                        if (user != null) {
                            BCrypt.Result result = BCrypt.verifyer().verify(password.getText().toString().toCharArray(), user.passwordHash);
                            if (result.verified) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        checkSmsPermissionAndProceed();
                                    }
                                });
                            } else{
                                // Handle login failure (incorrect password)
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(MainActivity.this, "Login Failed", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                        } else {
                            // Handle login failure (user not found)
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(MainActivity.this, "User Not Found", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }
                }).start();
            }
        });

        signupButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                EditText usernameEditText = findViewById(R.id.editTextTextUsername);
                EditText passwordEditText = findViewById(R.id.editTextTextPassword);

                String username = usernameEditText.getText().toString(); // Get text from EditText
                String password = passwordEditText.getText().toString(); // Get text from EditText

                // Hash the password
                String passwordHash = BCrypt.withDefaults().hashToString(12, password.toCharArray());

                // Create a new User object
                User newUser = new User(username, passwordHash);

                // Insert the user into the database in a background thread
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        database.userDao().insert(newUser);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this, "Signup Successful", Toast.LENGTH_SHORT).show();

                                loginButton.performClick();
                            }
                        });
                    }
                }).start();
            }
        });
    }
    private void checkSmsPermissionAndProceed() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            // Permission already granted, proceed to weight logging screen
            startActivity(new Intent(this, WeightLoggingActivity.class));
        } else {
            // Permission not granted, show permission request screen
            setContentView(R.layout.permission_manager);
            Button requestPermissionButton = findViewById(R.id.request_permission_button);
            requestPermissionButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
                }
            });
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            boolean isSmsPermissionGranted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;

            // Store permission status in SharedPreferences
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit().putBoolean(KEY_SMS_PERMISSION, isSmsPermissionGranted).apply();
            startActivity(new Intent(this, WeightLoggingActivity.class));
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, proceed to weight logging screen
                Toast.makeText(this, "SMS permission granted.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "No Problem!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}