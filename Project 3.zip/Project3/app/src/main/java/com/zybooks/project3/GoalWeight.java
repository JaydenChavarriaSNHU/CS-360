package com.zybooks.project3;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class GoalWeight {
    @PrimaryKey
    public int userId;

    @ColumnInfo(name = "goal_weight")
    public double goalWeight;
}

